<footer>
	<wm-list type="horizontal" separator="pipe" alignment="center" clean="true">
		<ul>
			<li><a href="/#" class="wm-h-link-clean"><strong>Impressum</strong></a></li>
			<li><a href="/#" class="wm-h-link-clean"><strong>Datenschutz</strong></a></li>
			<li><a href="/#" class="wm-h-link-clean"><strong>Barrierefreiheit</strong></a></li>
		</ul>
	</wm-list>
	<p>
		<small>© Stadt Wien, Rathaus, A-1010 Wien</small>
	</p>
</footer>

<style>
	footer {
		width: 100%;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		gap: 0.5rem;
	}
	ul {
		display: flex;
		flex-direction: row;
		align-items: center;
		justify-content: center;
		gap: 0.6rem;
	}
</style>
