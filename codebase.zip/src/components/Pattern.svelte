<script>
	/**
	 * @type {{ title: any; }}
	 */
	export let component;
</script>

<div class="flex justify-center bg-neutral-100 w-full p-4 cursor-grab">
	<div class="text-sm">{component.title}</div>
</div>
