export type Canvas = {
	id: string;
	name: string;
	state: string;
};
