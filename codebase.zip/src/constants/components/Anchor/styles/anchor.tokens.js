import { css } from 'lit';

export const tokens = [css`
:host {
  --anchor-gap: var(--_anchor-gap, 1rem);
}`]