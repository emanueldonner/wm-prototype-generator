import { css } from 'lit';

export const tokens = [css`
:host {
  --quicklinks-gap: var(--_quicklinks-gap, 2rem);
}`]