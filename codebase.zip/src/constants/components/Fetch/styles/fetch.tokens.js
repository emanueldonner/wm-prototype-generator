import { css } from 'lit';

export const tokens = [css`
:host {
  --fetch-gap: var(--_fetch-gap, 1rem);
}`]