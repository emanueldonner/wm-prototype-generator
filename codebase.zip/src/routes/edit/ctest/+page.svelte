<script>
</script>

<main id="content">
	<section>
		<wm-carousel update>
			<wm-card size="m" blocklink class="first" inert>
				<h3 slot="heading">
					<a href="#">Erzherzog-Karl-Straße Süd - Lebenswertes Wohnquartier</a>
				</h3>

				<div slot="content">
					<p>
						Auf dem rund 19 Hektar großen Gebiet "Erzherzog-Karl-Straße Süd" im 22. Bezirk soll ein
						Wohnquartier mit Grün- und Freiräumen entstehen.
					</p>
				</div>

				<img
					slot="media"
					src="/images/pattern/cards/parkpickerl-prater.jpg"
					width="350"
					height="197"
				/>
			</wm-card>
			<wm-card size="m" blocklink class="current" inert>
				<h3 slot="heading">
					<a href="#">Oberlaa und Umgebung</a>
				</h3>

				<div slot="content">
					<p>
						Seit Oktober 2019 gilt eine Bausperre für die Ortskerne von Oberlaa und Unterlaa, um die
						historischen Gebäude zu erhalten.
					</p>
				</div>

				<img
					slot="media"
					src="/images/pattern/cards/parkpickerl-prater.jpg"
					width="350"
					height="197"
				/>
			</wm-card>
			<wm-card size="m" blocklink class inert>
				<h3 slot="heading">
					<a href="#">aspern Die Seestadt Wiens</a>
				</h3>

				<div slot="content">
					<p>
						In mehreren Etappen entstehen im 22. Bezirk hochwertiger Wohnraum für mehr als 25.000
						Menschen und über 20.000 Arbeits- und Ausbildungsplätze.
					</p>
				</div>

				<img
					slot="media"
					src="/images/pattern/cards/parkpickerl-prater.jpg"
					width="350"
					height="197"
				/>
			</wm-card>
			<wm-card size="m" blocklink class inert>
				<h3 slot="heading">
					<a href="#">Erzherzog-Karl-Straße Süd - Lebenswertes Wohnquartier</a>
				</h3>

				<div slot="content">
					<p>
						Auf dem rund 19 Hektar großen Gebiet "Erzherzog-Karl-Straße Süd" im 22. Bezirk soll ein
						Wohnquartier mit Grün- und Freiräumen entstehen.
					</p>
				</div>

				<img
					slot="media"
					src="/images/pattern/cards/parkpickerl-prater.jpg"
					width="350"
					height="197"
				/>
			</wm-card>
			<wm-card size="m" blocklink class="last" inert>
				<h3 slot="heading">
					<a href="#">Oberlaa und Umgebung</a>
				</h3>

				<div slot="content">
					<p>
						Seit Oktober 2019 gilt eine Bausperre für die Ortskerne von Oberlaa und Unterlaa, um die
						historischen Gebäude zu erhalten.
					</p>
				</div>

				<img
					slot="media"
					src="/images/pattern/cards/parkpickerl-prater.jpg"
					width="350"
					height="197"
				/>
			</wm-card>
		</wm-carousel>
	</section>
</main>
