<script>
	import Canvas from '../../components/Canvas.svelte';
</script>

<Canvas />
