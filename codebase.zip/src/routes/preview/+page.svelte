<wm-accordion
	class="w-full h-full"
	data-demo-pattern="wm-accordion-preview"
	open="false"
	multiple="false"
	><h3 class="w-full h-full" slot="heading">
		<div>Ist eine Mitgliedschaft beim Vorteilsclub der Stadt Wien mit Kosten verbunden?</div>
		<div class="w-full h-full" slot="content">
			<p class="w-full h-full" />
			<div>
				Nein. Die Mitgliedschaft im Vorteilsclub der Stadt Wien ist absolut kostenlos und ohne
				Bindung.
			</div>
			<h3 class="w-full h-full" slot="heading">
				<div>Wer kann Mitglied im Vorteilsclub der Stadt Wien werden?</div>
				<div class="w-full h-full" slot="content">
					<p class="w-full h-full" />
					<div>
						Jede natürliche Person mit Wohnsitz in Österreich, die das 16. Lebensjahr vollendet hat.
					</div>
				</div>
			</h3>
		</div>
	</h3></wm-accordion
>
