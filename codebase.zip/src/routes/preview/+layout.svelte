<script>
</script>

<div>
	<link rel="stylesheet" href="/wiener-melange/assets/css/base.min.css" />
	<link rel="stylesheet" href="/wiener-melange/assets/css/base-tokens.min.css" />
	<link rel="stylesheet" href="/wiener-melange/assets/css/wiener-melange.min.css" />
	<slot />
</div>
