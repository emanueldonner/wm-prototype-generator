/* @copyright Stadt Wien - Wiener Melange v2 */
import{b as t}from"./lit-element-a22611a3.js";
/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const e=e=>null!=e?e:t;export{e as l};
