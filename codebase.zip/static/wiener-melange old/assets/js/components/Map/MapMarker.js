/* @copyright Stadt Wien - Wiener Melange v2 */
import{s as t}from"../../lit-element-a22611a3.js";class e extends t{static properties={label:{type:String},lat:{type:String},lng:{type:String}};constructor(){super(),this.label="",this.lat="",this.lng=""}}customElements.define("wm-mapmarker",e);export{e as MapMarker};
