/* @copyright Stadt Wien - Wiener Melange v2 */
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
function n(n,o,r){return n?o():null==r?void 0:r()}export{n};
