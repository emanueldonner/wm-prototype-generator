/* @copyright Stadt Wien - Wiener Melange v2 */
class t{host;constructor(t){(this.host=t).addController(this)}hostConnected(){}hostDisconnected(){}hasNamedSlot(t){return null!==this.host.querySelector(`:scope > [slot="${t}"]`)}}export{t as SlotController};
