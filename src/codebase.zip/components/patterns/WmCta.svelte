<script>
	export let href = '/#';
	export let text = 'Mehr erfahren';
</script>

<wm-cta data-demo-pattern="wm-cta-preview">
	<a {href}>{text}</a>
</wm-cta>
