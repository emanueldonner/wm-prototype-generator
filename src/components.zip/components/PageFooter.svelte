<footer>
	<wm-list type="horizontal" separator="pipe" alignment="center" clean="true">
		<ul>
			<li><a href="/#" class="wm-h-link-clean"><strong>Impressum</strong></a></li>
			<li><a href="/#" class="wm-h-link-clean"><strong>Datenschutz</strong></a></li>
			<li><a href="/#" class="wm-h-link-clean"><strong>Barrierefreiheit</strong></a></li>
		</ul>
	</wm-list>
	<p>
		<small>© Stadt Wien, Rathaus, A-1010 Wien</small>
	</p>
</footer>
